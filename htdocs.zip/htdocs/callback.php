<?php
    ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require 'notify_vps.php';

$secretKey = "sk_live_5263bf7ced825b21facb421618da0468fd1a16b3"; // your secret key
$reference = $_GET['reference'] ?? null;

if (!$reference) {
    die("No reference supplied");
}

// Verify transaction with Paystack
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.paystack.co/transaction/verify/" . $reference);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Authorization: Bearer $secretKey"
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if ($result && $result['status'] && $result['data']['status'] === 'success') {
    $amountPaid = $result['data']['amount'] / 100; // convert back from kobo
    $email = $result['data']['customer']['email'];

    // ✅ Extract transaction details
    $transactionId  = $result['data']['id'];          // Paystack transaction ID
    $invoiceNumber  = $result['data']['reference'];   // Paystack reference
    $paymentMethod  = $result['data']['channel'];     // Payment method (card, bank, ussd, etc.)

    // ✅ Update DB
    $conn = new mysqli("sql313.infinityfree.com", "if0_39741603", "mkala3771", "if0_39741603_dlink_network");
    if ($conn->connect_error) {
        die("DB Connection failed: " . $conn->connect_error);
    }
     $user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT username, phone_number FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($clientName, $clientPhone);
$stmt->fetch();
$stmt->close();

// Normalize phone
$clientPhone = preg_replace('/\D/', '', $clientPhone); // remove spaces, dashes

if (strlen($clientPhone) === 10 && str_starts_with($clientPhone, '07')) {
    $clientPhone = '254' . substr($clientPhone, 1);
}


    $stmt = $conn->prepare("INSERT INTO payments (user_id, transaction_id, invoice_number, amount, payment_method, status, payment_date) 
                            VALUES (?, ?, ?, ?, ?, 'completed', NOW())");
    $stmt->bind_param("iisds", $_SESSION['user_id'], $transactionId, $invoiceNumber, $amountPaid, $paymentMethod);
    $stmt->execute();
    
    file_put_contents(
    __DIR__ . '/phone_debug.log',
    "Phone sent to VPS: " . var_export($clientPhone, true) . PHP_EOL,
    FILE_APPEND
);

    notifyVPS([
        'secret'      => 'MY_SECRET_123',
    'payment_id'   => $transactionId,
    'amount'       => $amountPaid,
    'user_id'      => $clientName,
     'phone'        => $clientPhone,   // ✅ ADD THIS
    'payment_date' => date('Y-m-d H:i:s'),
    'status'       => 'completed'
]);

    
    
   
 // Fetch current user info (status and created_at)
    $userRes = $conn->query("SELECT status, created_at FROM users WHERE id = " . $_SESSION['user_id']);
    $user = $userRes->fetch_assoc();
    $createdAt = new DateTime($user['created_at']);
    $today = new DateTime();

    // Check if current subscription has expired
    $expiry = clone $createdAt;
    $expiry->modify('+30 days'); // assuming package is 30 days from created_at

    if ($expiry >= $today) {
       // ✅ Paid before expiry → extend from current expiry
    $newCreatedAt = $expiry->format('Y-m-d H:i:s'); 
    $conn->query("UPDATE users SET status = 'active', created_at = '$newCreatedAt' WHERE id = " . $_SESSION['user_id']);
 } else {
        // Paid after expiry → set queued
        $conn->query("UPDATE users SET status = 'queued', created_at = DATE_ADD(CURDATE(), INTERVAL 30 DAY) WHERE id = " . $_SESSION['user_id']);
        // Expiry will auto-generate from new created_at
    }
    // ✅ Extend subscription expiry (add 30 days)
    // $conn->query("UPDATE users SET status = 'queued', created_at = DATE_ADD(CURDATE(), INTERVAL 30 DAY) WHERE id = " . $_SESSION['user_id']);

    // Redirect back to dashboard with success + invoice ref
    header("Location: index.php?payment=success&ref=" . $invoiceNumber);
    exit();
} else {
    header("Location: index.php?payment=failed&ref=" . $reference);
    exit();
}
