<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
// DB connection
/*
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname     = "dlink_network";
*/
// DB connection

$servername = "sql313.infinityfree.com";
$db_username = "if0_39741603";
$db_password = "mkala3771";
$dbname     = "if0_39741603_dlink_network";


$conn = new mysqli($servername, $db_username, $db_password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT first_name, last_name, phone_number, email FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$fullName = trim($user['first_name'] . ' ' . $user['last_name']);
$phone = $user['phone_number'];
$email = $user['email'];


// Fetch user + router + package info
$sql = "SELECT 
            u.first_name, 
            u.last_name, 
            r.mac_address, 
            r.ip_address, 
            p.package_name, 
            p.speed, 
            p.price,
            u.Expiry
        FROM users u
        LEFT JOIN routers r ON u.router_id = r.id
        LEFT JOIN packages p ON u.package_id = p.id
        WHERE u.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Assign variables
$fullName   = trim($user['first_name'] . ' ' . $user['last_name']);
$ipAddress  = $user['ip_address'] ?? 'N/A';
$macAddress = $user['mac_address'] ?? 'N/A';
$planName   = $user['package_name'] ?? 'Unknown Plan';
$planSpeed  = $user['speed'] ?? 'N/A';
$expiryDate = $user['Expiry'] ?? null;
$planPrice  = isset($user['price']) ? 'KES ' . number_format($user['price'], 2) . ' / month' : 'N/A';
// ensure $user exists and extract numeric package price
$packagePriceNumber = 0.00;
if (!empty($user) && isset($user['price']) && is_numeric($user['price'])) {
    $packagePriceNumber = (float) $user['price'];
}

// formatted strings used in invoice modal
$priceFormatted      = 'KES ' . number_format($packagePriceNumber, 2);
$quantity            = 1;
$subtotal            = $packagePriceNumber * $quantity;
$subtotalFormatted   = 'KES ' . number_format($subtotal, 2);
$totalDueFormatted   = $subtotalFormatted;

// Fetch the latest notice
$notice_sql = "SELECT message, link FROM notices ORDER BY created_at DESC LIMIT 1";
$notice_result = $conn->query($notice_sql);
$notice = $notice_result->fetch_assoc();

/*
// Fetch payment history (include invoice_number)
$sql = "SELECT invoice_number, amount, payment_date, status 
        FROM payments 
        WHERE user_id = ? 
        ORDER BY payment_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$paymentHistoryResult = $stmt->get_result();
$payments = $paymentHistoryResult->fetch_all(MYSQLI_ASSOC);

// Get latest invoice number or default to N/A
$invoice_number = 'N/A';
if (!empty($payments) && !empty($payments[0]['invoice_number'])) {
    $invoice_number = $payments[0]['invoice_number'];
    
}
*/

// Fetch total paid from payments table
$sql = "SELECT COALESCE(SUM(amount), 0) AS total_paid 
        FROM payments 
        WHERE user_id = ? AND status = 'completed'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$paymentData = $result->fetch_assoc();
if ($expiryDate && strtotime($expiryDate) <= time()) {
    // Expired — total paid is zero
    $totalPaid = 'KES 0.00';
} else {
    $totalPaid = 'KES ' . number_format($paymentData['total_paid'], 2);
}
$paidAmountNumber = floatval(str_replace(['KES ', ','], '', $totalPaid));

// Fetch payment history
$sql = "SELECT amount, payment_date, status 
        FROM payments 
        WHERE user_id = ? 
        ORDER BY payment_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$paymentHistoryResult = $stmt->get_result();
$payments = $paymentHistoryResult->fetch_all(MYSQLI_ASSOC);

$stmt->close();
$conn->close();


$secretKey = "sk_live_5263bf7ced825b21facb421618da0468fd1a16b3"; // Your SECRET KEY

$email = $email;
$amount = $subtotal * 100; // Paystack expects amount in the smallest currency unit

$fields = [
  'email' => $email,
  'amount' => $amount,
  'callback_url' => "http://dlinknetwork.wuaze.com/callback.php"
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.paystack.co/transaction/initialize");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Authorization: Bearer $secretKey",
  "Cache-Control: no-cache"
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if ($result["status"]) {
    echo $result["data"]["authorization_url"]; // return the URL
} else {
    echo "error: " . $result["message"];
}
