<?php
session_start();
require 'notify_vps.php';
$secretKey = "sk_live_5263bf7ced825b21facb421618da0468fd1a16b3"; // your secret key
$reference = $_GET['reference'] ?? null;

if (!$reference) {
    die("No reference supplied");
}

// Verify transaction with Paystack
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.paystack.co/transaction/verify/" . $reference);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  "Authorization: Bearer $secretKey"
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if ($result && $result['status'] && $result['data']['status'] === 'success') {
    $amountPaid = $result['data']['amount'] / 100; // convert back from kobo
    $email = $result['data']['customer']['email'];
    $transactionId = $result['data']['id']; // Paystack transaction ID
    $invoiceNumber = $reference; // Use reference as invoice number
    $paymentMethod = "Mobile Money"; // Or dynamic if needed

    // ✅ Update DB
    $conn = new mysqli("sql313.infinityfree.com", "if0_39741603", "mkala3771", "if0_39741603_dlink_network");

     $user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT username, phone_number FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($clientName, $clientPhone);
$stmt->fetch();
$stmt->close();

// Normalize phone
$clientPhone = preg_replace('/\D/', '', $clientPhone); // remove spaces, dashes

if (strlen($clientPhone) === 10 && str_starts_with($clientPhone, '07')) {
    $clientPhone = '254' . substr($clientPhone, 1);
}

    $stmt = $conn->prepare("INSERT INTO payments (user_id, amount, status, payment_date, invoice_number, transaction_id, payment_method) VALUES (?, ?, 'completed', NOW(), ?, ?, ?)");
    $stmt->bind_param("idsss", $_SESSION['user_id'], $amountPaid, $invoiceNumber, $transactionId, $paymentMethod);
    $stmt->execute();

 file_put_contents(
    __DIR__ . '/phone_debug_newCl.log',
    "Phone sent to VPS: " . var_export($clientPhone, true) . PHP_EOL,
    FILE_APPEND
);

    notifyVPS([
        'secret'      => 'MY_SECRET_123',
    'payment_id'   => $transactionId,
    'amount'       => $amountPaid,
    'user_id'      => $clientName,
     'phone'        => $clientPhone,   // ✅ ADD THIS
    'payment_date' => date('Y-m-d H:i:s'),
    'status'       => 'completed'
]);


    
    // ✅ Update user subscription details
    $packageId = $_SESSION['new_package_id'] ?? null;
    if ($packageId) {
        $update = $conn->prepare("UPDATE users SET status = 'queued', package_id = ?, created_at = DATE_ADD(CURDATE(), INTERVAL 30 DAY) WHERE id = ?");
        $update->bind_param("ii", $packageId, $_SESSION['user_id']);
        $update->execute();
    }

    // Redirect back to dashboard with success flag
    header("Location: index.php?payment=success");
    exit();
} else {
    header("Location: index.php?payment=failed");
    exit();
}
?>
